package es.ubu.lsi.model.asociacion;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;


@Entity
@Table(name="Incidencia")
public class Incidencia implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Temporal(TemporalType.DATE)
	private Date fecha;
	
	private int nif;
	
	@Column(name="anotacion")
	private String anotacion;
	
	
	private TipoIncidencia idtipo;
	
	
	
	

}
