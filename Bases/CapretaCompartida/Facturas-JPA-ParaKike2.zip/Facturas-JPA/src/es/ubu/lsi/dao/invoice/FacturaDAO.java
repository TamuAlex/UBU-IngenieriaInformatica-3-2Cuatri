package es.ubu.lsi.dao.invoice;

import javax.persistence.EntityManager;

import es.ubu.lsi.dao.JpaDAO;
import es.ubu.lsi.model.invoice.Factura;

public class FacturaDAO extends JpaDAO<Factura, Long>{

	public FacturaDAO(EntityManager em) {
		super(em);
		// TODO Auto-generated constructor stub
	}

}
